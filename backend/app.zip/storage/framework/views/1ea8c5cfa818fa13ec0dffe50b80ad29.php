<?php $__env->startSection('title', 'Tambah Pengembalian - Panel Admin'); ?>
<?php $__env->startSection('header-title', 'Form Pengembalian Alat'); ?>

<?php $__env->startSection('content'); ?>
<div class="max-w-2xl bg-white rounded-lg shadow-sm border border-gray-200 p-6">
    
    <?php if(session('error')): ?>
        <div class="mb-4 bg-red-50 border border-red-200 text-red-800 p-3 rounded-lg text-sm">
            <?php echo e(session('error')); ?>

        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('admin.pengembalian.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
       <!-- Pilihan Transaksi Peminjaman -->
        <div class="mb-4">

            <label class="block text-gray-700 text-sm font-semibold mb-2">
                Pilih Transaksi Peminjaman (Status: Dipinjam)
            </label>

            <div class="relative" id="peminjaman-dropdown">

                <!-- Input Search -->
                <input
                    type="text"
                    id="peminjaman-search"
                    placeholder="Cari nama peminjam atau tanggal pinjam..."
                    autocomplete="off"
                    class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">

                <!-- ID Peminjaman yang dikirim ke Controller -->
                <input
                    type="hidden"
                    name="peminjaman_id"
                    id="peminjaman_id"
                    value="<?php echo e(old('peminjaman_id')); ?>"
                    required>

                <!-- Dropdown hasil pencarian -->
                <div
                    id="peminjaman-options"
                    class="hidden absolute z-20 w-full mt-1 bg-white border border-gray-300 rounded-lg shadow-lg max-h-60 overflow-y-auto">

                    <?php $__currentLoopData = $peminjamans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pjm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <?php
                            $listAlat = '';

                            foreach($pjm->detailPinjam as $detail) {
                                $nama_alat = $detail->alat->nama_alat ?? 'Alat Dihapus';

                                $listAlat .= "- {$nama_alat} (Jumlah: {$detail->jumlah} pcs)<br>";
                            }

                            $namaPeminjam = $pjm->user->name ?? 'User Dihapus';

                            $tanggalPinjam = \Carbon\Carbon::parse($pjm->tgl_pinjam)
                                ->format('d M Y');
                        ?>

                        <button
                            type="button"
                            class="peminjaman-option w-full text-left px-3 py-2 hover:bg-blue-50 transition"
                            data-id="<?php echo e($pjm->id); ?>"
                            data-name="<?php echo e($namaPeminjam); ?>"
                            data-date="<?php echo e($tanggalPinjam); ?>"
                            data-alat="<?php echo e($listAlat); ?>">

                            <div class="font-medium text-gray-800">
                                <?php echo e($namaPeminjam); ?>

                            </div>

                            <div class="text-xs text-gray-500">
                                Tgl Pinjam: <?php echo e($tanggalPinjam); ?>

                            </div>

                        </button>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
            </div>

            <?php $__errorArgs = ['peminjaman_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="text-red-500 text-xs"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        </div>

        <!-- Info Box: Menampilkan Alat yang dipinjam secara otomatis -->
        <div id="info-alat-container" class="mb-4 p-4 bg-blue-50 border border-blue-200 rounded-lg hidden">
            <p class="text-sm font-semibold text-blue-800 mb-2">Alat yang harus dikembalikan:</p>
            <div id="daftar-alat" class="text-sm text-blue-700 font-medium ml-2"></div>
        </div>

        <!-- Pilihan Petugas Penyetuju -->
        <div class="mb-4">
            <label class="block text-gray-700 text-sm font-semibold mb-2">Pilih Petugas yang Menerima/Menyetujui</label>
            <select name="petugas_id" required class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                <option value="">-- Pilih Petugas --</option>
                <?php $__currentLoopData = $petugas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($p->id); ?>" <?php echo e(old('petugas_id') == $p->id ? 'selected' : ''); ?>>
                        <?php echo e($p->name); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <?php $__errorArgs = ['petugas_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500 text-xs"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <!-- Dropdown Pilihan Kondisi Alat -->
        <div class="mb-4">
            <label class="block text-gray-700 text-sm font-semibold mb-2">Kondisi Alat Saat Dikembalikan</label>
            <select name="kondisi_kembali" required class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                <option value="baik" <?php echo e(old('kondisi_kembali') == 'baik' ? 'selected' : ''); ?>>Baik</option>
                <option value="rusak ringan" <?php echo e(old('kondisi_kembali') == 'rusak ringan' ? 'selected' : ''); ?>>Rusak Ringan</option>
                <option value="rusak sedang" <?php echo e(old('kondisi_kembali') == 'rusak sedang' ? 'selected' : ''); ?>>Rusak Sedang</option>
                <option value="rusak berat" <?php echo e(old('kondisi_kembali') == 'rusak berat' ? 'selected' : ''); ?>>Rusak Berat</option>
            </select>
            <?php $__errorArgs = ['kondisi_kembali'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500 text-xs"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <!-- Denda -->
        <div class="mb-6">
            <label class="block text-gray-700 text-sm font-semibold mb-2">Denda Keterlambatan / Kerusakan (Rp) <span class="text-xs text-gray-400 font-normal">(Isi 0 jika tidak ada)</span></label>
            <input type="number" name="denda" value="<?php echo e(old('denda', 0)); ?>" min="0" required
                   class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
            <?php $__errorArgs = ['denda'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500 text-xs"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="flex justify-end space-x-2">
            <a href="<?php echo e(route('admin.pengembalian.index')); ?>" 
               class="bg-gray-300 hover:bg-gray-400 text-gray-800 px-4 py-2 rounded-lg text-sm font-semibold transition">Batal</a>
            <button type="submit" 
                    class="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg text-sm font-semibold transition">Simpan Pengembalian</button>
        </div>
    </form>
</div>

<!-- Script untuk Menampilkan Daftar Alat secara Dinamis -->
<script>

document.addEventListener('DOMContentLoaded', function () {

    // =================================================
    // SEARCH TRANSAKSI PEMINJAMAN
    // =================================================

    const peminjamanSearch =
        document.getElementById('peminjaman-search');

    const peminjamanOptions =
        document.getElementById('peminjaman-options');

    const peminjamanId =
        document.getElementById('peminjaman_id');


    // Buka dropdown ketika input diklik
    peminjamanSearch.addEventListener('focus', function () {

        peminjamanOptions.classList.remove('hidden');

    });


    // Search peminjaman
    peminjamanSearch.addEventListener('input', function () {

        const keyword =
            this.value.toLowerCase().trim();

        peminjamanOptions.classList.remove('hidden');

        document.querySelectorAll('.peminjaman-option').forEach(option => {

            const name =
                option.dataset.name.toLowerCase();

            const date =
                option.dataset.date.toLowerCase();

            if (
                name.includes(keyword) ||
                date.includes(keyword)
            ) {

                option.classList.remove('hidden');

            } else {

                option.classList.add('hidden');

            }

        });

    });

    // PILIH TRANSAKSI PEMINJAMAN
    document.querySelectorAll('.peminjaman-option').forEach(option => {

        option.addEventListener('click', function () {

            const nama =
                this.dataset.name;

            const tanggal =
                this.dataset.date;

            const id =
                this.dataset.id;

            const alatData =
                this.dataset.alat;


            // Tampilkan data pada search bar
            peminjamanSearch.value =
                nama + ' - Tgl Pinjam: ' + tanggal;


            // Simpan ID peminjaman
            peminjamanId.value = id;


            // Tutup dropdown
            peminjamanOptions.classList.add('hidden');


            // Tampilkan daftar alat
            showAlatDetails(alatData);

        });

    });

    // TAMPILKAN ALAT
    function showAlatDetails(alatData) {

        const container =
            document.getElementById('info-alat-container');

        const daftarAlat =
            document.getElementById('daftar-alat');


        if (alatData) {

            daftarAlat.innerHTML = alatData;

            container.classList.remove('hidden');

        } else {

            container.classList.add('hidden');

            daftarAlat.innerHTML = '';

        }

    }


    // =================================================
    // KLIK DI LUAR DROPDOWN
    // =================================================

    document.addEventListener('click', function (event) {

        if (!event.target.closest('#peminjaman-dropdown')) {

            peminjamanOptions.classList.add('hidden');

        }

    });


    // =================================================
    // OLD VALUE / VALIDATION ERROR
    // =================================================

    const oldId =
        peminjamanId.value;

    if (oldId) {

        const selected =
            document.querySelector(
                '.peminjaman-option[data-id="' + oldId + '"]'
            );

        if (selected) {

            const nama =
                selected.dataset.name;

            const tanggal =
                selected.dataset.date;

            const alatData =
                selected.dataset.alat;


            peminjamanSearch.value =
                nama + ' - Tgl Pinjam: ' + tanggal;


            showAlatDetails(alatData);

        }

    }

});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/resources/views/admin/pengembalian/create.blade.php ENDPATH**/ ?>