<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Laporan Peminjaman Alat</title>
    <style>
        @page { margin: 24px; }
        body { font-family: 'Helvetica', Arial, sans-serif; color: #1f2937; font-size: 11px; }
        h1 { font-size: 16px; margin: 0 0 4px 0; }
        .subtitle { font-size: 10px; color: #6b7280; margin-bottom: 12px; }
        .filter-box { margin-bottom: 14px; font-size: 10px; color: #374151; }
        .filter-box span { display: inline-block; margin-right: 18px; }
        table { width: 100%; border-collapse: collapse; }
        th, td { border: 1px solid #d1d5db; padding: 5px 6px; text-align: left; vertical-align: top; }
        th { background-color: #f3f4f6; text-transform: uppercase; font-size: 9px; letter-spacing: 0.03em; }
        td { font-size: 10px; }
        .text-center { text-align: center; }
        .badge { display: inline-block; padding: 2px 6px; border-radius: 8px; font-size: 9px; font-weight: bold; }
        .badge-diajukan { background: #fef9c3; color: #854d0e; }
        .badge-dipinjam { background: #dbeafe; color: #1e40af; }
        .badge-dikembalikan { background: #d1fae5; color: #065f46; }
        .badge-telat { background: #fee2e2; color: #991b1b; }
        .footer { margin-top: 16px; font-size: 9px; color: #9ca3af; }
        ul { margin: 0; padding-left: 14px; }
    </style>
</head>
<body>
    <h1>Laporan Peminjaman Alat</h1>
    <div class="subtitle">Dicetak pada <?php echo e(now()->format('d M Y H:i')); ?> WIB</div>

    <div class="filter-box">
        <span><strong>Estimasi Waktu:</strong>
            <?php echo e($start_date ? \Carbon\Carbon::parse($start_date)->format('d M Y') : 'Semua'); ?>

            &ndash;
            <?php echo e($end_date ? \Carbon\Carbon::parse($end_date)->format('d M Y') : 'Semua'); ?>

        </span>
        <span><strong>Kondisi/Status:</strong> <?php echo e($status ? ucfirst($status) : 'Semua Status'); ?></span>
        <span><strong>Total Data:</strong> <?php echo e($laporan->count()); ?></span>
    </div>

    <table>
        <thead>
            <tr>
                <th class="text-center">No</th>
                <th>Peminjam</th>
                <th>Tgl Pinjam</th>
                <th>Rencana Kembali</th>
                <th>Detail Alat</th>
                <th class="text-center">Status</th>
                <th>Kondisi Kembali</th>
                <th>Denda</th>
                <th>Petugas Verifikasi</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $laporan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td class="text-center"><?php echo e($index + 1); ?></td>
                    <td><?php echo e($item->user->name ?? 'User Dihapus'); ?></td>
                    <td><?php echo e(\Carbon\Carbon::parse($item->tgl_pinjam)->format('d M Y')); ?></td>
                    <td><?php echo e($item->tgl_kembali_plan ? \Carbon\Carbon::parse($item->tgl_kembali_plan)->format('d M Y') : '-'); ?></td>
                    <td>
                        <ul>
                            <?php $__currentLoopData = $item->detailPinjam; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($detail->alat->nama_alat ?? 'Alat Dihapus'); ?> (Jumlah: <?php echo e($detail->jumlah); ?>)</li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </td>
                    <td class="text-center">
                        <span class="badge badge-<?php echo e($item->status); ?>"><?php echo e(ucfirst($item->status)); ?></span>
                    </td>
                    <td><?php echo e($item->pengembalian->kondisi_kembali ?? '-'); ?></td>
                    <td><?php echo e(isset($item->pengembalian) ? 'Rp ' . number_format($item->pengembalian->denda, 0, ',', '.') : '-'); ?></td>
                    <td><?php echo e($item->pengembalian->petugas->name ?? '-'); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="9" class="text-center">Tidak ada data laporan peminjaman berdasarkan filter yang dipilih.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>

    <div class="footer">Sistem Peminjaman Alat &mdash; Laporan ini dibuat otomatis oleh sistem.</div>
</body>
</html>
<?php /**PATH /var/www/resources/views/laporan/cetak.blade.php ENDPATH**/ ?>