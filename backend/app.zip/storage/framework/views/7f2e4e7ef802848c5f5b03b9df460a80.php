<?php $__env->startSection('title', 'Proses Pengembalian - Petugas'); ?>
<?php $__env->startSection('header-title', 'Proses Pengajuan Pengembalian'); ?>

<?php $__env->startSection('content'); ?>
<div class="max-w-2xl bg-white rounded-lg shadow-sm border border-gray-200 p-6">

    <?php if(session('error')): ?>
        <div class="mb-4 bg-red-50 border border-red-200 text-red-800 p-3 rounded-lg text-sm">
            <?php echo e(session('error')); ?>

        </div>
    <?php endif; ?>
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="mb-4 bg-red-50 border border-red-200 text-red-800 p-3 rounded-lg text-sm"><?php echo e($error); ?></div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <!-- Info Peminjam & Alat -->
    <div class="mb-6 p-4 bg-blue-50 border border-blue-200 rounded-lg">
        <p class="text-sm text-blue-900"><span class="font-semibold">Peminjam:</span> <?php echo e($peminjaman->user->name ?? 'User Dihapus'); ?></p>
        <p class="text-sm text-blue-900"><span class="font-semibold">Tgl Pinjam:</span> <?php echo e(\Carbon\Carbon::parse($peminjaman->tgl_pinjam)->format('d M Y')); ?></p>
        <p class="text-sm text-blue-900"><span class="font-semibold">Rencana Kembali:</span> <?php echo e(\Carbon\Carbon::parse($peminjaman->tgl_kembali_plan)->format('d M Y')); ?></p>
        <p class="text-sm text-blue-900 mt-2 font-semibold">Alat yang diajukan untuk dikembalikan:</p>
        <ul class="list-disc list-inside text-sm text-blue-800 ml-2">
            <?php $__currentLoopData = $peminjaman->detailPinjam; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($detail->alat->nama_alat ?? 'Alat Dihapus'); ?> (Jumlah: <?php echo e($detail->jumlah); ?>)</li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>

    <form id="form-proses-pengembalian">
        <?php echo csrf_field(); ?>

        <!-- Dropdown Kondisi Alat (dipakai saat menyetujui) -->
        <div class="mb-4">
            <label class="block text-gray-700 text-sm font-semibold mb-2">Kondisi Alat Saat Dikembalikan</label>
            <select name="kondisi_kembali" required class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                <option value="baik" <?php echo e(old('kondisi_kembali') == 'baik' ? 'selected' : ''); ?>>Baik</option>
                <option value="rusak ringan" <?php echo e(old('kondisi_kembali') == 'rusak ringan' ? 'selected' : ''); ?>>Rusak Ringan</option>
                <option value="rusak sedang" <?php echo e(old('kondisi_kembali') == 'rusak sedang' ? 'selected' : ''); ?>>Rusak Sedang</option>
                <option value="rusak berat" <?php echo e(old('kondisi_kembali') == 'rusak berat' ? 'selected' : ''); ?>>Rusak Berat</option>
            </select>
            <p class="text-xs text-gray-400 mt-1">Hanya diperlukan jika pengajuan disetujui.</p>
        </div>

        <!-- Denda Telat (otomatis) -->
        <?php
            $hariTelat = $peminjaman->hitungHariTelat();
            $dendaTelat = $peminjaman->hitungDendaTelat();
        ?>
        <div class="mb-4">
            <label class="block text-gray-700 text-sm font-semibold mb-2">
                Denda Keterlambatan (Rp)
                <span class="text-xs text-gray-400 font-normal">(Otomatis: Rp 2.000 per hari)</span>
            </label>
            <input type="text" id="denda_telat_tampil" value="<?php echo e(number_format($dendaTelat, 0, ',', '.')); ?>" readonly
                   class="w-full px-3 py-2 border border-gray-300 rounded-lg bg-gray-100 text-gray-700 cursor-not-allowed">
            <p class="text-xs mt-1 <?php echo e($hariTelat > 0 ? 'text-red-600' : 'text-gray-400'); ?>">
                <?php if($hariTelat > 0): ?>
                    Terlambat <?php echo e($hariTelat); ?> hari dari rencana kembali (<?php echo e(\Carbon\Carbon::parse($peminjaman->tgl_kembali_plan)->format('d M Y')); ?>).
                <?php else: ?>
                    Tidak terlambat.
                <?php endif; ?>
            </p>
        </div>

        <!-- Denda Rusak (manual) -->
        <div class="mb-4">
            <label class="block text-gray-700 text-sm font-semibold mb-2">Denda Kerusakan (Rp) <span class="text-xs text-gray-400 font-normal">(Isi manual, 0 jika tidak ada)</span></label>
            <input type="number" name="denda_rusak" id="denda_rusak" value="<?php echo e(old('denda_rusak', 0)); ?>" min="0"
                   class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
        </div>

        <!-- Total -->
        <div class="mb-4 p-3 bg-gray-50 border border-gray-200 rounded-lg flex justify-between text-sm">
            <span class="font-semibold text-gray-700">Total Denda</span>
            <span class="font-bold text-red-600" id="denda_total">Rp 0</span>
        </div>

        <!-- Catatan penolakan -->
        <div class="mb-6">
            <label class="block text-gray-700 text-sm font-semibold mb-2">Catatan Penolakan <span class="text-xs text-gray-400 font-normal">(Ditampilkan ke peminjam jika ditolak)</span></label>
            <textarea name="catatan_pengembalian" rows="2" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" placeholder="Contoh: Alat belum dikembalikan secara fisik ke gudang."></textarea>
        </div>

        <div class="flex justify-between items-center">
            <a href="<?php echo e(route('petugas.pengembalian.index')); ?>"
               class="bg-gray-300 hover:bg-gray-400 text-gray-800 px-4 py-2 rounded-lg text-sm font-semibold transition">Batal</a>

            <div class="flex gap-2">
                <button type="submit"
                        formaction="<?php echo e(route('petugas.pengembalian.tolak', $peminjaman->id)); ?>"
                        formnovalidate
                        onclick="return confirm('Yakin ingin menolak pengajuan pengembalian ini?')"
                        class="bg-red-500 hover:bg-red-600 text-white px-4 py-2 rounded-lg text-sm font-semibold transition">
                    Tolak Pengembalian
                </button>
                <button type="submit"
                        formaction="<?php echo e(route('petugas.pengembalian.setujui', $peminjaman->id)); ?>"
                        onclick="return confirm('Setujui pengembalian alat ini? Stok akan otomatis dipulihkan.')"
                        class="bg-emerald-600 hover:bg-emerald-700 text-white px-4 py-2 rounded-lg text-sm font-semibold transition">
                    Menyetujui
                </button>
            </div>
        </div>
    </form>
</div>

<script>
    // Form dikirim via formaction ke route setujui/tolak yang berbeda,
    // keduanya method POST sehingga cukup satu <form> dengan dua tombol submit.
    document.getElementById('form-proses-pengembalian').setAttribute('method', 'POST');

    // Total denda = denda telat (otomatis) + denda rusak (manual)
    (function () {
        const dendaTelat = <?php echo e($dendaTelat); ?>;
        const rusak = document.getElementById('denda_rusak');
        const total = document.getElementById('denda_total');
        function hitung() {
            const jumlah = dendaTelat + (parseInt(rusak.value, 10) || 0);
            total.textContent = 'Rp ' + jumlah.toLocaleString('id-ID');
        }
        rusak.addEventListener('input', hitung);
        hitung();
    })();
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/resources/views/petugas/pengembalian/proses.blade.php ENDPATH**/ ?>