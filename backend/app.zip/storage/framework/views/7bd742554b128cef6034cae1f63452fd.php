<?php $__env->startSection('title', 'Dashboard Admin – Sistem Peminjaman'); ?>
<?php $__env->startSection('header-title', 'Ringkasan Sistem'); ?>

<?php $__env->startSection('content'); ?>
    <!-- Alert Selamat Datang -->
    <div class="mb-6 bg-emerald-50 border border-emerald-200 text-emerald-800 p-4 rounded-lg shadow-sm">
        Selamat datang, <strong class="font-semibold"><?php echo e(auth()->user()->name); ?></strong>! Anda login sebagai hak akses
        <span class="uppercase font-bold text-emerald-900"><?php echo e(auth()->user()->role); ?></span>.
    </div>

    <!-- Kartu Ringkasan per Menu -->
    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5 mb-6">

        <!-- Kelola User -->
        <a href="<?php echo e(route('admin.user.index')); ?>" class="block bg-white rounded-lg shadow-sm border border-gray-200 p-5 hover:shadow-md hover:border-blue-300 transition">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-sm font-semibold text-gray-500">Kelola User</p>
                    <p class="text-3xl font-bold text-gray-800 mt-1"><?php echo e($stats['user']['total']); ?></p>
                </div>
                <div class="w-11 h-11 rounded-lg bg-blue-100 text-blue-600 flex items-center justify-center text-xl font-bold">U</div>
            </div>
            <p class="text-xs text-gray-500 mt-3">
                Admin: <?php echo e($stats['user']['admin']); ?> &middot;
                Petugas: <?php echo e($stats['user']['petugas']); ?> &middot;
                Peminjam: <?php echo e($stats['user']['peminjam']); ?>

            </p>
        </a>

        <!-- Kelola Kategori -->
        <a href="<?php echo e(route('admin.kategori.index')); ?>" class="block bg-white rounded-lg shadow-sm border border-gray-200 p-5 hover:shadow-md hover:border-purple-300 transition">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-sm font-semibold text-gray-500">Kelola Kategori</p>
                    <p class="text-3xl font-bold text-gray-800 mt-1"><?php echo e($stats['kategori']['total']); ?></p>
                </div>
                <div class="w-11 h-11 rounded-lg bg-purple-100 text-purple-600 flex items-center justify-center text-xl font-bold">K</div>
            </div>
            <p class="text-xs text-gray-500 mt-3">Total kategori alat terdaftar</p>
        </a>

        <!-- Kelola Alat -->
        <a href="<?php echo e(route('admin.alat.index')); ?>" class="block bg-white rounded-lg shadow-sm border border-gray-200 p-5 hover:shadow-md hover:border-amber-300 transition">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-sm font-semibold text-gray-500">Kelola Alat</p>
                    <p class="text-3xl font-bold text-gray-800 mt-1"><?php echo e($stats['alat']['total']); ?></p>
                </div>
                <div class="w-11 h-11 rounded-lg bg-amber-100 text-amber-600 flex items-center justify-center text-xl font-bold">A</div>
            </div>
            <p class="text-xs text-gray-500 mt-3">Total stok tersedia: <?php echo e($stats['alat']['total_stok']); ?> unit</p>
        </a>

        <!-- Kelola Peminjaman -->
        <a href="<?php echo e(route('admin.peminjaman.index')); ?>" class="block bg-white rounded-lg shadow-sm border border-gray-200 p-5 hover:shadow-md hover:border-indigo-300 transition">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-sm font-semibold text-gray-500">Kelola Peminjaman</p>
                    <p class="text-3xl font-bold text-gray-800 mt-1"><?php echo e($stats['peminjaman']['total']); ?></p>
                </div>
                <div class="w-11 h-11 rounded-lg bg-indigo-100 text-indigo-600 flex items-center justify-center text-xl font-bold">P</div>
            </div>
            <p class="text-xs text-gray-500 mt-3">
                Diajukan: <?php echo e($stats['peminjaman']['diajukan']); ?> &middot;
                Dipinjam: <?php echo e($stats['peminjaman']['dipinjam']); ?> &middot;
                Kembali: <?php echo e($stats['peminjaman']['dikembalikan']); ?> &middot;
                Telat: <?php echo e($stats['peminjaman']['telat']); ?>

            </p>
        </a>

        <!-- Kelola Pengembalian -->
        <a href="<?php echo e(route('admin.pengembalian.index')); ?>" class="block bg-white rounded-lg shadow-sm border border-gray-200 p-5 hover:shadow-md hover:border-emerald-300 transition">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-sm font-semibold text-gray-500">Kelola Pengembalian</p>
                    <p class="text-3xl font-bold text-gray-800 mt-1"><?php echo e($stats['pengembalian']['total']); ?></p>
                </div>
                <div class="w-11 h-11 rounded-lg bg-emerald-100 text-emerald-600 flex items-center justify-center text-xl font-bold">R</div>
            </div>
            <p class="text-xs text-gray-500 mt-3">
                <?php if($stats['pengembalian']['menunggu'] > 0): ?>
                    <span class="text-amber-600 font-semibold"><?php echo e($stats['pengembalian']['menunggu']); ?> menunggu persetujuan</span>
                <?php else: ?>
                    Tidak ada pengajuan yang menunggu
                <?php endif; ?>
            </p>
        </a>

        <!-- Log Aktivitas -->
        <a href="<?php echo e(route('admin.logAktivitas.index')); ?>" class="block bg-white rounded-lg shadow-sm border border-gray-200 p-5 hover:shadow-md hover:border-gray-400 transition">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-sm font-semibold text-gray-500">Log Aktivitas</p>
                    <p class="text-3xl font-bold text-gray-800 mt-1"><?php echo e($stats['log_aktivitas']['total']); ?></p>
                </div>
                <div class="w-11 h-11 rounded-lg bg-gray-200 text-gray-700 flex items-center justify-center text-xl font-bold">L</div>
            </div>
            <p class="text-xs text-gray-500 mt-3">Lihat seluruh riwayat aktivitas &rarr;</p>
        </a>

    </div>

    <!-- Cetak Laporan -->
    <div class="bg-white rounded-lg shadow-sm border border-gray-200 p-5 flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
            <h3 class="text-md font-bold text-gray-800">Butuh laporan peminjaman?</h3>
            <p class="text-sm text-gray-500 mt-1">Filter berdasarkan estimasi waktu dan kondisi, lalu cetak dalam format PDF.</p>
        </div>
        <a href="<?php echo e(route('admin.laporan.index')); ?>"
            class="bg-gray-800 hover:bg-gray-900 text-white px-4 py-2 rounded-lg text-sm font-semibold transition whitespace-nowrap">
            Buka Cetak Laporan
        </a>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/resources/views/admin/dashboard.blade.php ENDPATH**/ ?>