<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Riwayat Pinjam – Peminjam</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

    <nav class="navbar navbar-expand-lg navbar-dark bg-primary mb-4">
        <div class="container">
            <a class="navbar-brand" href="<?php echo e(route('peminjam.katalog')); ?>">Panel Peminjam</a>
            <div class="d-flex">
                <a href="<?php echo e(route('peminjam.katalog')); ?>" class="btn btn-outline-light btn-sm me-2">Katalog Alat</a>
                <form action="<?php echo e(route('logout')); ?>" method="POST" class="d-inline">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="btn btn-light btn-sm text-primary">Logout</button>
                </form>
            </div>
        </div>
    </nav>

    <div class="container">
        <?php if(session('success')): ?>
            <div class="alert alert-success"><?php echo e(session('success')); ?></div>
        <?php endif; ?>
        <?php if(session('error')): ?>
            <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
        <?php endif; ?>

        <h3 class="mb-3">Riwayat Peminjaman Saya</h3>

        <div class="card shadow-sm">
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered align-middle">
                        <thead class="table-light">
                            <tr>
                                <th>Tgl Pinjam</th>
                                <th>Rencana Kembali</th>
                                <th>Detail Alat</th>
                                <th>Status</th>
                                <th style="min-width: 220px;">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $peminjamans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e(\Carbon\Carbon::parse($item->tgl_pinjam)->format('d M Y')); ?></td>
                                    <td><?php echo e(\Carbon\Carbon::parse($item->tgl_kembali_plan)->format('d M Y')); ?></td>
                                    <td>
                                        <ul class="mb-0 ps-3 small">
                                            <?php $__currentLoopData = $item->detailPinjam; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li>
                                                    <strong><?php echo e($detail->alat->nama_alat ?? 'Alat Dihapus'); ?></strong>
                                                    (Jumlah: <?php echo e($detail->jumlah); ?>)
                                                </li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    </td>
                                    <td>
                                        <?php if($item->status === 'diajukan'): ?>
                                            <span class="badge bg-secondary">Menunggu Persetujuan Pinjam</span>
                                        <?php elseif($item->status === 'dipinjam' && $item->pengembalian_diajukan_at): ?>
                                            <span class="badge bg-warning text-dark">Menunggu Persetujuan Pengembalian</span>
                                        <?php elseif($item->status === 'dipinjam'): ?>
                                            <span class="badge bg-primary">Sedang Dipinjam</span>
                                        <?php elseif($item->status === 'dikembalikan'): ?>
                                            <span class="badge bg-success">Sudah Dikembalikan</span>
                                        <?php elseif($item->status === 'telat'): ?>
                                            <span class="badge bg-danger">Telat</span>
                                        <?php else: ?>
                                            <span class="badge bg-light text-dark"><?php echo e(ucfirst($item->status)); ?></span>
                                        <?php endif; ?>

                                        <?php if($item->status === 'dikembalikan' && $item->pengembalian): ?>
                                            <div class="small text-muted mt-1">
                                                Kondisi: <?php echo e(ucfirst($item->pengembalian->kondisi_kembali)); ?><br>
                                                Denda: Rp <?php echo e(number_format($item->pengembalian->denda, 0, ',', '.')); ?>

                                                <?php if($item->pengembalian->denda_telat > 0): ?>
                                                    <br>- Telat <?php echo e($item->pengembalian->hari_telat); ?> hari: Rp <?php echo e(number_format($item->pengembalian->denda_telat, 0, ',', '.')); ?>

                                                <?php endif; ?>
                                                <?php if($item->pengembalian->denda_rusak > 0): ?>
                                                    <br>- Rusak: Rp <?php echo e(number_format($item->pengembalian->denda_rusak, 0, ',', '.')); ?>

                                                <?php endif; ?>
                                            </div>
                                        <?php endif; ?>

                                        <?php if($item->catatan_pengembalian): ?>
                                            <div class="alert alert-danger py-1 px-2 mt-2 mb-0 small">
                                                <strong>Pengajuan pengembalian ditolak:</strong>
                                                <?php echo e($item->catatan_pengembalian); ?>

                                            </div>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if($item->status === 'diajukan'): ?>
                                            <form action="<?php echo e(route('peminjam.peminjaman.destroy', $item->id)); ?>" method="POST"
                                                  onsubmit="return confirm('Yakin ingin menghapus pengajuan peminjaman ini?')">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-outline-danger btn-sm">Hapus</button>
                                            </form>
                                        <?php elseif($item->status === 'dipinjam' && $item->pengembalian_diajukan_at): ?>
                                            <form action="<?php echo e(route('peminjam.pengembalian.batal', $item->id)); ?>" method="POST"
                                                  onsubmit="return confirm('Batalkan pengajuan pengembalian ini?')">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-outline-secondary btn-sm">Hapus (Batalkan)</button>
                                            </form>
                                        <?php elseif($item->status === 'dipinjam'): ?>
                                            <form action="<?php echo e(route('peminjam.pengembalian.ajukan', $item->id)); ?>" method="POST"
                                                  onsubmit="return confirm('Ajukan pengembalian untuk alat ini?')">
                                                <?php echo csrf_field(); ?>
                                                <button type="submit" class="btn btn-primary btn-sm">Ajukan Pengembalian</button>
                                            </form>
                                        <?php else: ?>
                                            <span class="text-muted small">Tidak ada aksi</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="5" class="text-center text-muted">Belum ada riwayat peminjaman.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

</body>
</html>
<?php /**PATH /var/www/resources/views/peminjam/riwayat.blade.php ENDPATH**/ ?>