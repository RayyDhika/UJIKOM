<?php $__env->startSection('title', 'Log Aktivitas - Panel Admin'); ?>
<?php $__env->startSection('header-title', 'Log Aktivitas Sistem'); ?>

<?php $__env->startSection('content'); ?>
    <div class="bg-white rounded-lg shadow-sm overflow-hidden border border-gray-200">
        <div class="p-5 border-b border-gray-200 bg-gray-50 flex flex-col md:flex-row justify-between items-center gap-4">
            <div>
                <h3 class="text-lg font-bold text-gray-800">Riwayat Log Aktivitas</h3>
                <p class="text-xs text-gray-500 mt-1">Catatan seluruh aktivitas CRUD yang terjadi di sistem.</p>
            </div>

            <form action="<?php echo e(route('admin.logAktivitas.index')); ?>" method="GET" class="flex w-full md:w-80">
                <input type="text" name="search" value="<?php echo e(request('search')); ?>" placeholder="Cari nama user / aktivitas..."
                    class="w-full px-3 py-2 text-sm border border-gray-300 rounded-l-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                <button type="submit" class="bg-gray-800 hover:bg-gray-900 text-white px-4 py-2 text-sm font-semibold rounded-r-lg transition">
                    Cari
                </button>
                <?php if(request('search')): ?>
                    <a href="<?php echo e(route('admin.logAktivitas.index')); ?>"
                        class="ml-2 bg-gray-300 hover:bg-gray-400 text-gray-700 px-3 py-2 text-sm rounded-lg flex items-center transition">
                        Reset
                    </a>
                <?php endif; ?>
            </form>
        </div>

        <div class="overflow-x-auto">
            <table class="w-full text-left border-collapse">
                <thead>
                    <tr class="bg-gray-100 text-gray-600 text-sm uppercase tracking-wider">
                        <th class="py-3 px-4 border-b">Waktu</th>
                        <th class="py-3 px-4 border-b">User</th>
                        <th class="py-3 px-4 border-b">Aktivitas</th>
                    </tr>
                </thead>
                <tbody class="text-gray-700 text-sm">
                    <?php $__empty_1 = true; $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr class="hover:bg-gray-50 transition">
                            <td class="py-3 px-4 border-b whitespace-nowrap"><?php echo e($log->created_at->format('d M Y H:i')); ?></td>
                            <td class="py-3 px-4 border-b font-medium text-gray-900"><?php echo e($log->user->name ?? 'Sistem'); ?></td>
                            <td class="py-3 px-4 border-b"><?php echo e($log->aktivitas); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="3" class="py-6 text-center text-gray-500">Belum ada log aktivitas.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <div class="p-4 border-t border-gray-200 bg-gray-50">
            <?php echo e($logs->links()); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/resources/views/admin/logAktivitas/index.blade.php ENDPATH**/ ?>