
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title', 'Dashboard Admin'); ?></title>
    <!-- Memuat Tailwind CSS CDN -->
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 font-sans antialiased">

    <div class="flex h-screen overflow-hidden">

        <!-- SIDEBAR -->
        <aside class="w-64 bg-gray-900 text-white flex flex-col hidden md:flex">
            <div class="p-5 text-xl font-bold tracking-wider border-b border-gray-800">
                <?php if(auth()->user()->role == 'admin'): ?>
                    PANEL ADMIN
                <?php elseif(auth()->user()->role == 'petugas'): ?>
                    PANEL PETUGAS
                <?php elseif(auth()->user()->role == 'peminjam'): ?>
                    PANEL PEMINJAM
                <?php endif; ?>
            </div>
            <nav class="flex-1 p-4 space-y-2">
                <!-- MENU KHUSUS ADMIN -->
                <!-- MENU DASHBOARD -->
                <?php if(auth()->user()->role === 'admin'): ?>

                    <a href="<?php echo e(route('admin.dashboard')); ?>"
                        class="block px-4 py-2 rounded-lg transition
                        <?php echo e(request()->routeIs('admin.dashboard')
                            ? 'bg-gray-800 text-white font-medium shadow'
                            : 'text-gray-400 hover:bg-gray-800 hover:text-white'); ?>">
                        Dashboard
                    </a>

                    <a href="<?php echo e(route('admin.user.index')); ?>"
                        class="block px-4 py-2 rounded-lg transition
                        <?php echo e(request()->routeIs('admin.user.*')
                            ? 'bg-gray-800 text-white font-medium shadow'
                            : 'text-gray-400 hover:bg-gray-800 hover:text-white'); ?>">
                        Kelola User
                    </a>

                    <a href="<?php echo e(route('admin.kategori.index')); ?>"
                        class="block px-4 py-2 rounded-lg transition
                        <?php echo e(request()->routeIs('admin.kategori.*')
                            ? 'bg-gray-800 text-white font-medium shadow'
                            : 'text-gray-400 hover:bg-gray-800 hover:text-white'); ?>">
                        Kelola Kategori
                    </a>

                    <a href="<?php echo e(route('admin.alat.index')); ?>"
                        class="block px-4 py-2 rounded-lg transition
                        <?php echo e(request()->routeIs('admin.alat.*')
                            ? 'bg-gray-800 text-white font-medium shadow'
                            : 'text-gray-400 hover:bg-gray-800 hover:text-white'); ?>">
                        Kelola Alat
                    </a>

                    <a href="<?php echo e(route('admin.peminjaman.index')); ?>"
                        class="block px-4 py-2 rounded-lg transition
                        <?php echo e(request()->routeIs('admin.peminjaman.*')
                            ? 'bg-gray-800 text-white font-medium shadow'
                            : 'text-gray-400 hover:bg-gray-800 hover:text-white'); ?>">
                        Kelola Peminjaman
                    </a>

                    <a href="<?php echo e(route('admin.pengembalian.index')); ?>"
                        class="block px-4 py-2 rounded-lg transition
                        <?php echo e(request()->routeIs('admin.pengembalian.*')
                            ? 'bg-gray-800 text-white font-medium shadow'
                            : 'text-gray-400 hover:bg-gray-800 hover:text-white'); ?>">
                        Kelola Pengembalian
                    </a>

                    <a href="<?php echo e(route('admin.laporan.index')); ?>"
                        class="block px-4 py-2 rounded-lg transition
                        <?php echo e(request()->routeIs('admin.laporan.*')
                            ? 'bg-gray-800 text-white font-medium shadow'
                            : 'text-gray-400 hover:bg-gray-800 hover:text-white'); ?>">
                        Cetak Laporan
                    </a>

                    <a href="<?php echo e(route('admin.logAktivitas.index')); ?>"
                        class="block px-4 py-2 rounded-lg transition
                        <?php echo e(request()->routeIs('admin.log-aktivitas.*')
                            ? 'bg-gray-800 text-white font-medium shadow'
                            : 'text-gray-400 hover:bg-gray-800 hover:text-white'); ?>">
                        Log Aktivitas
                    </a>

                <?php endif; ?>
                <!-- MENU KHUSUS PETUGAS -->
                <?php if(auth()->user()->role === 'petugas'): ?>
                    <a href="<?php echo e(route('petugas.peminjaman.index')); ?>"
                        class="block px-4 py-2 rounded-lg transition <?php echo e(request()->routeIs('petugas.peminjaman*') ? 'bg-gray-800 text-white font-medium shadow' : 'text-gray-400 hover:bg-gray-800 hover:text-white'); ?>">
                        Persetujuan Peminjam</a>

                     <a href="<?php echo e(route('petugas.pengembalian.index')); ?>"
                        class="block px-4 py-2 rounded-lg transition <?php echo e(request()->routeIs('petugas.pengembalian*') ? 'bg-gray-800 text-white font-medium shadow' : 'text-gray-400 hover:bg-gray-800 hover:text-white'); ?>">
                        Pemantauan Pengembalian</a>
                   
                    <a href="<?php echo e(route('petugas.laporan.index')); ?>"
                        class="block px-4 py-2 rounded-lg transition <?php echo e(request()->routeIs('petugas.laporan*') ? 'bg-gray-800 text-white font-medium shadow' : 'text-gray-400 hover:bg-gray-800 hover:text-white'); ?>">
                        Cetak Laporan
                    </a>
                <?php endif; ?>
                <?php if(auth()->user()->role === 'peminjam'): ?>
                    <a href="<?php echo e(route('peminjam.katalog')); ?>" class="block px-4 py-2 rounded-lg transition <?php echo e(request()->routeIs('peminjam.katalog') ? 'bg-gray-800 text-white font-medium shadow' : 'text-gray-400 hover:bg-gray-800 hover:text-white'); ?>">Katalog Alat</a>
                    <a href="<?php echo e(route('peminjam.riwayat')); ?>" class="block px-4 py-2 rounded-lg transition <?php echo e(request()->routeIs('peminjam.riwayat') ? 'bg-gray-800 text-white font-medium shadow' : 'text-gray-400 hover:bg-gray-800 hover:text-white'); ?>">Riwayat Peminjaman</a>
                <?php endif; ?>
            </nav>

            <!-- MENU PROFIL DI BAGIAN BAWAH SIDEBAR -->
            <div class="px-4 pb-3">
                <a href="<?php echo e(route('profile.edit')); ?>"
                    class="flex items-center gap-3 rounded-lg px-4 py-3 transition
                    <?php echo e(request()->routeIs('profile.*') ? 'bg-blue-600 text-white font-semibold' : 'text-gray-300 hover:bg-gray-800 hover:text-white'); ?>">
                    <?php if(auth()->user()->foto_profile): ?>
                        <img src="<?php echo e(asset(auth()->user()->foto_profile)); ?>" alt="Foto profil" class="h-9 w-9 rounded-full border border-gray-600 object-cover">
                    <?php else: ?>
                        <span class="flex h-9 w-9 items-center justify-center rounded-full bg-gray-700 font-bold text-white"><?php echo e(strtoupper(substr(auth()->user()->name, 0, 1))); ?></span>
                    <?php endif; ?>
                    <span class="min-w-0">
                        <span class="block text-sm">Profil Saya</span>
                        <span class="block truncate text-xs opacity-75"><?php echo e(auth()->user()->name); ?></span>
                    </span>
                </a>
            </div>

            <div class="p-4 border-t border-gray-800 text-sm text-gray-400">
                Logged in as: <span class="text-white font-semibold"><?php echo e(auth()->user()->name); ?></span>
            </div>
        </aside>

        <!-- MAIN CONTENT CONTAINER -->
        <div class="flex-1 flex flex-col overflow-y-auto">

            <!-- NAVBAR ATAS -->
            <header class="bg-white shadow-sm h-16 flex items-center justify-between px-6 z-10">
                <div class="text-lg font-semibold text-gray-800">
                    <?php echo $__env->yieldContent('header-title', 'Dashboard'); ?>
                </div>
                <div>
                    <form action="<?php echo e(route('logout')); ?>" method="POST" onsubmit="return confirm('Yakin ingin logout?')">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="bg-red-500 hover:bg-red-600 text-white text-sm font-semibold px-4 py-2 rounded-lg transition">
                            Logout
                        </button>
                    </form>
                </div>
            </header>

            <!-- KONTEN UTAMA HALAMAN -->
            <main class="flex-1 p-6">
                <?php echo $__env->yieldContent('content'); ?>
            </main>

        </div>
    </div>

</body>
</html><?php /**PATH /var/www/resources/views/layouts/app.blade.php ENDPATH**/ ?>