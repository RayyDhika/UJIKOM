<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AdminController;
use App\Http\Controllers\PetugasController;
use App\Http\Controllers\PeminjamController;
use App\Http\Controllers\AuthController;

Route::get('/', function () {
    return view('welcome');
});

// admin
Route::middleware(['auth', 'role:admin'])->prefix('admin')->name('admin.')->group(function () {
    Route::get('/dashboard', [AdminController::class, 'index'])->name('dashboard');

    // Log Aktivitas (halaman terpisah, tidak lagi tampil di dashboard)
    Route::get('/logAktivitas', [AdminController::class, 'logAktivitas'])->name('logAktivitas.index');

    // Cetak Laporan
    Route::get('/laporan/peminjaman', [AdminController::class, 'indexLaporan'])->name('laporan.index');
    Route::get('/laporan/peminjaman/cetak', [AdminController::class, 'cetakLaporan'])->name('laporan.cetak');

    // CRUD Alat
    Route::get('/alat', [AdminController::class, 'indexAlat'])->name('alat.index');
    Route::post('/alat', [AdminController::class, 'storeAlat'])->name('alat.store');

    // CRUD User
    Route::get('/users', [AdminController::class, 'indexUser'])->name('user.index');
    Route::get('/users/create', [AdminController::class, 'createUser'])->name('user.create');
    Route::post('/users', [AdminController::class, 'storeUser'])->name('user.store');
    Route::get('/users/{id}/edit', [AdminController::class, 'editUser'])->name('user.edit');
    Route::put('/users/{id}', [AdminController::class, 'updateUser'])->name('user.update');
    Route::delete('/users/{id}', [AdminController::class, 'destroyUser'])->name('user.destroy');

    //crud kategori
    Route::get('/kategori', [AdminController::class, 'indexKategori'])->name('kategori.index');
    Route::get('/kategori/create', [AdminController::class, 'createKategori'])->name('kategori.create');
    Route::post('/kategori', [AdminController::class, 'storeKategori'])->name('kategori.store');
    Route::get('/kategori/{id}/edit', [AdminController::class, 'editKategori'])->name('kategori.edit');
    Route::put('/kategori/{id}', [AdminController::class, 'updateKategori'])->name('kategori.update');
    Route::delete('/kategori/{id}', [AdminController::class, 'destroyKategori'])->name('kategori.destroy');

     //crud alat
    Route::get('/alat', [AdminController::class, 'indexAlat'])->name('alat.index');
    Route::get('/alat/create', [AdminController::class, 'createAlat'])->name('alat.create');
    Route::post('/alat', [AdminController::class, 'storeAlat'])->name('alat.store');
    Route::get('/alat/{id}/edit', [AdminController::class, 'editAlat'])->name('alat.edit');
    Route::put('/alat/{id}', [AdminController::class, 'updateAlat'])->name('alat.update');
    Route::delete('/alat/{id}', [AdminController::class, 'destroyAlat'])->name('alat.destroy');

    // Route peminjaman
    Route::get('/peminjaman', [AdminController::class, 'indexPeminjaman'])->name('peminjaman.index');
    Route::get('/peminjaman/create', [AdminController::class, 'createPeminjaman'])->name('peminjaman.create');
    Route::post('/peminjaman', [AdminController::class, 'storePeminjaman'])->name('peminjaman.store');
    Route::put('/peminjaman/{id}/status', [AdminController::class, 'updateStatusPeminjaman'])->name('peminjaman.updateStatus');
    Route::delete('/peminjaman/{id}', [AdminController::class, 'destroyPeminjaman'])->name('peminjaman.destroy');

     # CRUD Pengembalian
    Route::get('/pengembalian', [AdminController::class, 'indexPengembalian'])->name('pengembalian.index');
    Route::get('/pengembalian/create', [AdminController::class, 'createPengembalian'])->name('pengembalian.create');
    Route::post('/pengembalian', [AdminController::class, 'storePengembalian'])->name('pengembalian.store'); 
    // Proses persetujuan pengajuan pengembalian dari peminjam
    Route::get('/pengembalian/proses/{peminjaman}', [AdminController::class, 'prosesPengembalianForm'])->name('pengembalian.proses');
    Route::post('/pengembalian/proses/{peminjaman}/setujui', [AdminController::class, 'setujuiPengembalian'])->name('pengembalian.setujui');
    Route::post('/pengembalian/proses/{peminjaman}/tolak', [AdminController::class, 'tolakPengembalian'])->name('pengembalian.tolak');
    Route::delete('/pengembalian/{id}', [AdminController::class, 'destroyPengembalian'])->name('pengembalian.destroy');

});


// petugas
Route::middleware(['auth', 'role:petugas,admin'])->prefix('petugas')->name('petugas.')->group(function () {
    // Peminjaman & Persetujuan
    Route::get('/peminjaman', [PetugasController::class, 'indexPeminjaman'])->name('peminjaman.index');
    Route::post('/peminjaman/{id}/setujui', [PetugasController::class, 'setujuiPeminjaman'])->name('peminjaman.setujui');
    Route::post('/peminjaman/{id}/tolak', [PetugasController::class, 'tolakPeminjaman'])->name('peminjaman.tolak');

    // Pengembalian & Denda
    Route::get('/pengembalian', [PetugasController::class, 'indexPengembalian'])
        ->name('pengembalian.index');
    // Proses persetujuan pengajuan pengembalian dari peminjam
    Route::get('/pengembalian/proses/{peminjaman}', [PetugasController::class, 'prosesPengembalianForm'])->name('pengembalian.proses');
    Route::post('/pengembalian/proses/{peminjaman}/setujui', [PetugasController::class, 'setujuiPengembalian'])->name('pengembalian.setujui');
    Route::post('/pengembalian/proses/{peminjaman}/tolak', [PetugasController::class, 'tolakPengembalian'])->name('pengembalian.tolak');
    // Cetak laporan
    Route::get('/laporan/peminjaman', [PetugasController::class, 'indexLaporan'])
    ->name('laporan.index');

    Route::get('/laporan/peminjaman/cetak', [PetugasController::class, 'cetakLaporan'])
        ->name('laporan.cetak');


});

// peminjam
Route::middleware(['auth', 'role:peminjam'])->prefix('peminjam')->name('peminjam.')->group(function () {
    // Katalog & Pengajuan
    Route::get('/katalog', [PeminjamController::class, 'katalogAlat'])->name('katalog');
    Route::post('/peminjaman/ajukan', [PeminjamController::class, 'ajukanPeminjaman'])->name('peminjaman.ajukan');
    Route::get('/riwayat', [PeminjamController::class, 'riwayatPeminjaman'])->name('riwayat');
    Route::delete('/peminjaman/{id}', [PeminjamController::class, 'destroyPeminjaman'])->name('peminjaman.destroy');

    // Pengembalian alat (diajukan peminjam, disetujui/ditolak admin/petugas)
    Route::post('/pengembalian/{id}/ajukan', [PeminjamController::class, 'ajukanPengembalian'])->name('pengembalian.ajukan');
    Route::delete('/pengembalian/{id}/batal', [PeminjamController::class, 'batalkanPengembalian'])->name('pengembalian.batal');
});

// Route Tamu (Belum Login)
Route::middleware('guest')->group(function () {
    Route::get('/login', [AuthController::class, 'showLoginForm'])->name('login');
    Route::post('/login', [AuthController::class, 'login']);
});

// Route Logout (Harus sudah login)
Route::post('/logout', [AuthController::class, 'logout'])
    ->middleware('auth')
    ->name('logout');

