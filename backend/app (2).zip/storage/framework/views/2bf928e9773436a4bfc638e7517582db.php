<?php $__env->startSection('title', 'Edit Alat - Panel Admin'); ?>
<?php $__env->startSection('header-title', 'Edit Data Alat'); ?>

<?php $__env->startSection('content'); ?>
    <div class="max-w-2xl bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <form action="<?php echo e(route('admin.alat.update', $alat->id)); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <div class="mb-4">
                <label class="block text-gray-700 text-sm font-semibold mb-2">Nama Alat</label>
                <input type="text" name="nama_alat" value="<?php echo e(old('nama_alat', $alat->nama_alat)); ?>" required
                       class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
            </div>

            <div class="mb-4">
                <label class="block text-gray-700 text-sm font-semibold mb-2">Kategori</label>
                <select name="kategori_id" required class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                    <option value="">-- Pilih Kategori --</option>
                    <?php $__currentLoopData = $kategoris; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($kategori->id); ?>" <?php echo e(old('kategori_id', $alat->kategori_id) == $kategori->id ? 'selected' : ''); ?>>
                            <?php echo e($kategori->nama_kategori); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                <div>
                    <label class="block text-gray-700 text-sm font-semibold mb-2">Stok</label>
                    <input type="number" name="stok" value="<?php echo e(old('stok', $alat->stok)); ?>" min="0" required
                           class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                </div>
                <div>
                    <label class="block text-gray-700 text-sm font-semibold mb-2">Status Kondisi</label>
                    <input type="text" name="status_kondisi" value="<?php echo e(old('status_kondisi', $alat->status_kondisi)); ?>" required
                           class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                </div>
            </div>

            <div class="mb-4">
                <label class="block text-gray-700 text-sm font-semibold mb-2">Deskripsi</label>
                <textarea name="deskripsi" rows="3"
                          class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"><?php echo e(old('deskripsi', $alat->deskripsi)); ?></textarea>
            </div>

            <div class="mb-6">
                <label class="block text-gray-700 text-sm font-semibold mb-2">Gambar Alat <span class="text-xs text-gray-400 font-normal">(Biarkan kosong jika tidak ingin mengubah gambar)</span></label>
                <?php if($alat->gambar): ?>
                    <div class="mb-2">
                        <img src="<?php echo e(asset($alat->gambar)); ?>" alt="Preview" class="w-16 h-16 object-cover rounded-lg border">
                    </div>
                <?php endif; ?>
                <input type="file" name="gambar" accept="image/*"
                       class="w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-lg file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100">
            </div>

            <div class="flex justify-end space-x-2">
                <a href="<?php echo e(route('admin.alat.index')); ?>"
                   class="bg-gray-300 hover:bg-gray-400 text-gray-800 px-4 py-2 rounded-lg text-sm font-semibold transition">Batal</a>
                <button type="submit"
                        class="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg text-sm font-semibold transition">Perbarui</button>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/resources/views/admin/alat/edit.blade.php ENDPATH**/ ?>