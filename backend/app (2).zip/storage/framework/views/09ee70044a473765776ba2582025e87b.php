<?php $__env->startSection('title', 'Tambah Peminjaman - Panel Admin'); ?>
<?php $__env->startSection('header-title', 'Form Tambah Transaksi Peminjaman'); ?>

<?php $__env->startSection('content'); ?>     
<div class="bg-white rounded-lg shadow-sm border border-gray-200 p-6">

    
    <?php if(session('error')): ?>
        <div class="mb-4 bg-red-50 border border-red-200 text-red-800 p-3 rounded-lg text-sm">
            <?php echo e(session('error')); ?>

        </div>
    <?php endif; ?>

    
    <form action="<?php echo e(route('admin.peminjaman.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>

        
        <div class="mb-4">
            <label class="block text-gray-700 text-sm font-semibold mb-2">Pilih Peminjam (User)</label>
            <div class="relative" id="user-dropdown">

                
                <input type="text" id="user-search" placeholder="Cari nama atau email..." autocomplete="off"
                    class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                
                <input type="hidden" name="user_id" id="user_id" value="<?php echo e(old('user_id')); ?>" required>
                
                <div id="user-options" class="hidden absolute z-20 w-full mt-1 bg-white border border-gray-300 rounded-lg shadow-lg max-h-60 overflow-y-auto">

                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <button type="button" class="user-option w-full text-left px-3 py-2 hover:bg-blue-50 transition" data-id="<?php echo e($user->id); ?>" data-name="<?php echo e($user->name); ?>" data-email="<?php echo e($user->email); ?>">
                            <div class="font-medium text-gray-800">
                                <?php echo e($user->name); ?>

                            </div>
                            <div class="text-xs text-gray-500">
                                <?php echo e($user->email); ?>

                            </div>
                        </button>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>

        
        <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">

            
            <div>
                <label class="block text-gray-700 text-sm font-semibold mb-2">Tanggal Pinjam</label>
                <input type="date" name="tgl_pinjam" value="<?php echo e(old('tgl_pinjam', date('Y-m-d'))); ?>"required 
                    class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
            </div>

            
            <div>
                <label class="block text-gray-700 text-sm font-semibold mb-2">Rencana Tanggal Kembali</label>
                <input type="date" name="tgl_kembali_plan" value="<?php echo e(old('tgl_kembali_plan', date('Y-m-d', strtotime('+3 days')))); ?>" required
                    class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
            </div>
        </div>

        
        
        <div class="mb-6">

            <label class="block text-gray-700 text-sm font-semibold mb-2">
                Daftar Alat yang Dipinjam
            </label>

            <div id="alat-container" class="space-y-3">

                
                <div class="alat-row flex items-center gap-3">

                    
                    <div class="relative flex-1 alat-dropdown">

                        
                        <input
                            type="text"
                            placeholder="Cari alat..."
                            autocomplete="off"
                            class="alat-search w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                        >

                        
                        <input
                            type="hidden"
                            name="alat_id[]"
                            class="alat-id"
                            required
                        >

                        
                        <div
                            class="alat-options hidden absolute z-20 w-full mt-1 bg-white border border-gray-300 rounded-lg shadow-lg max-h-60 overflow-y-auto"
                        >

                            <?php $__currentLoopData = $alats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <button
                                    type="button"
                                    class="alat-option w-full text-left px-3 py-2 hover:bg-blue-50 transition"
                                    data-id="<?php echo e($alat->id); ?>"
                                    data-name="<?php echo e($alat->nama_alat); ?>"
                                    data-stok="<?php echo e($alat->stok); ?>"
                                >

                                    <div class="font-medium text-gray-800">
                                        <?php echo e($alat->nama_alat); ?>

                                    </div>

                                    <div class="text-xs text-gray-500">
                                        Stok: <?php echo e($alat->stok); ?>

                                    </div>

                                </button>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </div>

                    </div>


                    
                    <input
                        type="number"
                        name="jumlah[]"
                        value="1"
                        min="1"
                        placeholder="Jumlah"
                        required
                        class="w-24 px-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                    >


                    
                    <button
                        type="button"
                        onclick="removeRow(this)"
                        class="bg-red-500 hover:bg-red-600 text-white px-3 py-2 text-xs rounded-lg transition whitespace-nowrap"
                    >
                        Hapus
                    </button>

                </div>

            </div>


            
            <button
                type="button"
                onclick="addRow()"
                class="mt-3 bg-gray-200 hover:bg-gray-300 text-gray-700 text-xs font-semibold px-3 py-2 rounded-lg transition"
            >
                + Tambah Alat Lain
            </button>

        </div>


        
        
        
        <div class="flex justify-end space-x-2">

            
            <a
                href="<?php echo e(route('admin.peminjaman.index')); ?>"
                class="bg-gray-300 hover:bg-gray-400 text-gray-700 text-sm font-semibold px-4 py-2 rounded-lg transition"
            >
                Batal
            </a>


            
            <button
                type="submit"
                class="bg-blue-600 hover:bg-blue-700 text-white text-sm font-semibold px-4 py-2 rounded-lg transition"
            >
                Simpan Peminjaman
            </button>

        </div>

    </form>

</div>






<script>

document.addEventListener('DOMContentLoaded', function () {


    // =================================================
    // SEARCH PEMINJAM
    // =================================================

    const userSearch = document.getElementById('user-search');
    const userOptions = document.getElementById('user-options');
    const userId = document.getElementById('user_id');


    // Buka dropdown ketika input diklik
    userSearch.addEventListener('focus', function () {

        userOptions.classList.remove('hidden');

    });


    // Search user
    userSearch.addEventListener('input', function () {

        const keyword = this.value.toLowerCase().trim();

        userOptions.classList.remove('hidden');


        document.querySelectorAll('.user-option').forEach(option => {

            const name = option.dataset.name.toLowerCase();
            const email = option.dataset.email.toLowerCase();


            if (
                name.includes(keyword) ||
                email.includes(keyword)
            ) {

                option.classList.remove('hidden');

            } else {

                option.classList.add('hidden');

            }

        });

    });


    // Pilih user
    document.querySelectorAll('.user-option').forEach(option => {

        option.addEventListener('click', function () {

            userSearch.value =
                this.dataset.name +
                ' (' +
                this.dataset.email +
                ')';


            userId.value = this.dataset.id;


            userOptions.classList.add('hidden');

        });

    });



    // =================================================
    // SEARCH ALAT
    // =================================================

    function setupAlatDropdown(row) {

        const search = row.querySelector('.alat-search');

        const hiddenId = row.querySelector('.alat-id');

        const options = row.querySelector('.alat-options');


        // Buka dropdown
        search.addEventListener('focus', function () {

            options.classList.remove('hidden');

        });


        // Search alat
        search.addEventListener('input', function () {

            const keyword = this.value.toLowerCase().trim();

            options.classList.remove('hidden');


            row.querySelectorAll('.alat-option').forEach(option => {

                const name =
                    option.dataset.name.toLowerCase();


                if (name.includes(keyword)) {

                    option.classList.remove('hidden');

                } else {

                    option.classList.add('hidden');

                }

            });

        });


        // Pilih alat
        row.querySelectorAll('.alat-option').forEach(option => {

            option.addEventListener('click', function () {

                search.value =
                    this.dataset.name +
                    ' (Stok: ' +
                    this.dataset.stok +
                    ')';


                hiddenId.value =
                    this.dataset.id;


                options.classList.add('hidden');

            });

        });

    }



    // =================================================
    // AKTIFKAN SEARCH ALAT PERTAMA
    // =================================================

    const firstRow =
        document.querySelector('.alat-row');


    if (firstRow) {

        setupAlatDropdown(firstRow);

    }



    // =================================================
    // TAMBAH ROW ALAT
    // =================================================

    window.addRow = function () {

        const container =
            document.getElementById('alat-container');


        const firstRow =
            container.querySelector('.alat-row');


        const newRow =
            firstRow.cloneNode(true);


        // Reset search alat
        newRow.querySelector('.alat-search').value = '';


        // Reset ID alat
        newRow.querySelector('.alat-id').value = '';


        // Reset jumlah
        newRow.querySelector(
            'input[type="number"]'
        ).value = '1';


        // Tutup dropdown
        newRow.querySelector(
            '.alat-options'
        ).classList.add('hidden');


        // Masukkan row baru
        container.appendChild(newRow);


        // Aktifkan dropdown/search
        setupAlatDropdown(newRow);

    };



    // =================================================
    // HAPUS ROW ALAT
    // =================================================

    window.removeRow = function (button) {

        const rows =
            document.querySelectorAll('.alat-row');


        if (rows.length > 1) {

            button
                .closest('.alat-row')
                .remove();

        } else {

            alert(
                'Minimal harus ada 1 alat yang dipilih.'
            );

        }

    };



    // =================================================
    // KLIK DI LUAR DROPDOWN
    // =================================================

    document.addEventListener('click', function (event) {


        // Tutup dropdown user
        if (
            !event.target.closest('#user-dropdown')
        ) {

            userOptions.classList.add('hidden');

        }


        // Tutup dropdown alat
        document
            .querySelectorAll('.alat-dropdown')
            .forEach(dropdown => {

                if (
                    !event.target.closest('.alat-dropdown')
                ) {

                    dropdown
                        .querySelector('.alat-options')
                        .classList
                        .add('hidden');

                }

            });

    });

});

</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/resources/views/admin/peminjaman/create.blade.php ENDPATH**/ ?>