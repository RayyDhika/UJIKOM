<?php $__env->startSection('title', 'Pemantauan Pengembalian - Petugas'); ?>
<?php $__env->startSection('header-title', 'Pemantauan Pengembalian Alat'); ?>

<?php $__env->startSection('content'); ?>
    <div class="bg-white rounded-lg shadow-sm overflow-hidden border border-gray-200">
        <div class="p-5 border-b border-gray-200 bg-gray-50 flex flex-col md:flex-row justify-between items-center gap-4">
            <h3 class="text-lg font-bold text-gray-800">Riwayat Alat Kembali</h3>

            <div class="flex items-center gap-3 w-full md:w-auto">
                <!-- Form Search -->
                <form action="<?php echo e(route('petugas.pengembalian.index')); ?>" method="GET" class="flex w-full md:w-80">
                    <input type="text" name="search" value="<?php echo e(request('search')); ?>" placeholder="Cari nama peminjam..."
                           class="w-full px-3 py-2 text-sm border border-gray-300 rounded-l-lg focus:outline-none focus:ring-2 focus:ring-emerald-500">
                    <button type="submit" class="bg-gray-800 hover:bg-gray-900 text-white px-4 py-2 text-sm font-semibold rounded-r-lg transition">
                        Cari
                    </button>
                    <?php if(request('search')): ?>
                        <a href="<?php echo e(route('petugas.pengembalian.index')); ?>"
                           class="ml-2 bg-gray-300 hover:bg-gray-400 text-gray-700 px-3 py-2 text-sm rounded-lg flex items-center transition">
                            Reset
                        </a>
                    <?php endif; ?>
                </form>
            </div>
        </div>

        <div class="overflow-x-auto">
            <table class="w-full text-left border-collapse">
                <thead>
                    <tr class="bg-gray-100 text-gray-600 text-sm uppercase tracking-wider">
                        <th class="py-3 px-4 border-b">Tgl Kembali</th>
                        <th class="py-3 px-4 border-b">Peminjam</th>
                        <th class="py-3 px-4 border-b">Detail Alat</th>
                        <th class="py-3 px-4 border-b">Kondisi</th>
                        <th class="py-3 px-4 border-b">Denda</th>
                        <th class="py-3 px-4 border-b">Petugas Verifikasi</th>
                    </tr>
                </thead>
                <tbody class="text-gray-700 text-sm">
                    <?php $__empty_1 = true; $__currentLoopData = $pengembalians; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pengembalian): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr class="hover:bg-gray-50 transition align-top">
                            <td class="py-3 px-4 border-b whitespace-nowrap">
                                <?php echo e(\Carbon\Carbon::parse($pengembalian->tgl_kembali)->format('d M Y')); ?>

                            </td>
                            <td class="py-3 px-4 border-b font-medium text-gray-900">
                                <?php echo e($pengembalian->peminjaman->user->name ?? 'User Dihapus'); ?>

                            </td>
                            <td class="py-3 px-4 border-b">
                                <ul class="list-disc list-inside space-y-1 text-xs">
                                    <?php if($pengembalian->peminjaman): ?>
                                        <?php $__currentLoopData = $pengembalian->peminjaman->detailPinjam; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li>
                                                <span class="font-semibold"><?php echo e($detail->alat->nama_alat ?? 'Alat Dihapus'); ?></span> 
                                                (Jumlah: <?php echo e($detail->jumlah); ?>)
                                            </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                        <span class="text-red-500">Data peminjaman dihapus</span>
                                    <?php endif; ?>
                                </ul>
                            </td>
                            <td class="py-3 px-4 border-b">
                                <span class="px-2.5 py-1 text-xs font-semibold rounded-full 
                                    <?php echo e(strtolower($pengembalian->kondisi_kembali) == 'baik' ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'); ?>">
                                    <?php echo e(ucfirst($pengembalian->kondisi_kembali)); ?>

                                </span>
                            </td>
                            <td class="py-3 px-4 border-b text-red-600 font-semibold">
                                Rp <?php echo e(number_format($pengembalian->denda, 0, ',', '.')); ?>

                            </td>
                            <td class="py-3 px-4 border-b text-gray-600 text-xs font-medium">
                                <?php echo e($pengembalian->petugas->name ?? 'Sistem'); ?>

                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="6" class="py-6 text-center text-gray-500">Belum ada alat yang dikembalikan.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <div class="p-4 border-t border-gray-200 bg-gray-50">
            <?php echo e($pengembalians->links()); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/resources/views/petugas/pengembalian/index.blade.php ENDPATH**/ ?>